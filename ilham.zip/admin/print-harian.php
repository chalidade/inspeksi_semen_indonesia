<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    /* td { border: thin solid black } */
    </style>
  </head>
  <body>
    <table width="100%" border="0" style="border: 2px solid black;padding:5px;">
      <tr>
        <td rowspan="3" style="text-align:center" width="20%">Logo perusahaan</td>
        <td colspan="2" style="text-align:center" width="60%"><h3>LAPORAN HARIAN SAFETY</h3></td>
        <td rowspan="3" style="text-align:center" width="20%">Logo Perusahaan Kontraktor</td>
      </tr>
      <tr>
        <td width="7%">Doc No</td>
        <td>: </td>
      </tr>
      <tr>
        <td>Tanggal</td>
        <td>: </td>
      </tr>
    </table>
    <div class="" style="width:100%;height:150px;margin-top:20px;">
      <div class="" style="width:50%; float:left">
        <table width="100%" border="1" style="padding:3px;">
          <tr>
            <td style="width:30%">Pekerjaan </td>
            <td>: </td>
          </tr>
          <tr>
            <td>No Pekerjaan </td>
            <td>: </td>
          </tr>
          <tr>
            <td>Hari Kerja </td>
            <td>: </td>
          </tr>
          <tr>
            <td>No Pekerjaan </td>
            <td>: </td>
          </tr>
          <tr>
            <td>Total Pekerja </td>
            <td>: </td>
          </tr>
        </table>
      </div>
      <div class="" style="width:50%;float:right;">
        <table style="padding:3px;">
          <tr>
            <td colspan="2">Jenis Kegiatan</td>
          </tr>
          <tr>
            <td> <input required type="radio" name="" value=""> </td>
            <td>Inspeksi</td>
          </tr>
          <tr>
            <td> <input required type="radio" name="" value=""> </td>
            <td>Corektif / Troubleshooting</td>
          </tr>
          <tr>
            <td> <input required type="radio" name="" value=""> </td>
            <td>Other : <input required type="text" style="border: none;" name="" value=""> </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="width:100%">
      <table width="100%" border="1" style="text-align:center;">
        <tr>
          <td colspan="6" style="background:#c9fbf5e6;color:#000;">
            <h3 style="text-align:center;line-height:0px;text-transform:uppercase">Tabel Aktivitas</h3>
          </td>
        </tr>
        <tr style="text-align:center">
          <th>No</th>
          <th>Uraian Pekerjaan</th>
          <th>Identifikasi Bahaya</th>
          <th>Dampak</th>
          <th>Tindakan Kecelakaan</th>
          <th>Keterangan</th>
        </tr>
        <tr>
          <td>1</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>2</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>3</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>4</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>5</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>6</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </div>
<div class="" style="width:100%;margin-top:20px;">
    <div style="width:50%;float:left">
      <table border="1" style="width:100%;text-align:center">
        <tr>
          <td colspan="4" style="text-align:center;line-height:0px;"><h3>Kejadian</h3></td>
        </tr>
        <tr>
          <td></td>
          <td>Nearmiss</td>
          <td>Incident</td>
          <td>Accident</td>
        </tr>
        <tr>
          <td>Ringan</td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td> Berat</td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>Fatal</td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </div>

    <div class="width:50%; float:right">
      <table border="1" style="width:50%;">
        <tr>
          <td colspan="6" style="text-align:center;line-height:0px;"><h3>Jam Kerja</h3></td>
        </tr>
        <tr style="text-align:center">
          <td colspan="3">Normal</td>
          <td colspan="3">Overtime</td>
        </tr>
        <tr>
          <td width="30%">Jumlah Pekerja</td>
          <td width="10%"></td>
          <td>Org</td>
          <td width="30%">Jumlah Pekerja</td>
          <td width="10%"></td>
          <td>Org</td>
        </tr>
        <tr>
          <td>Jam Kerja Efektif</td>
          <td></td>
          <td>jam</td>
          <td>Jam Lembur</td>
          <td></td>
          <td>jam</td>
        </tr>
        <tr>
          <td>Jam Kerja Normal</td>
          <td></td>
          <td>jam</td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </div>
  </div>

  </body>
</html>
